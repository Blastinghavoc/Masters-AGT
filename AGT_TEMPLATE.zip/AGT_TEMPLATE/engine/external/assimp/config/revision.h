#ifndef ASSIMP_REVISION_H_INC
#define ASSIMP_REVISION_H_INC

#define GitVersion 0x0
#define GitBranch ""

#endif // ASSIMP_REVISION_H_INC
